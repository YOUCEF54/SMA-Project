package org.myworldgis.io.geojson;

public interface GeoJsonConstants {

    public final static String GEOJSON_EXTENSION = "geojson";

    public final static String JSON_EXTENSION = "json"; 

}

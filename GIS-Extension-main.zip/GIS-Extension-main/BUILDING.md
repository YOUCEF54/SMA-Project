## Building

```
sbt package
```

If compilation succeeds, `gis.jar` will be created.
